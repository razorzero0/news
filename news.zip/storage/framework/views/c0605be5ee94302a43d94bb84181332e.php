<div class="relative p-4 mt-20 md:mt-24">
    <div class="max-w-3xl mx-auto">
        <?php echo $__env->make('livewire.news_partials.news-content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <hr class="my-5 border-gray-600 ">
        <?php echo $__env->make('livewire.news_partials.news-latest-post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('livewire.news_partials.news-comments', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css" />
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
<?php $__env->stopPush(); ?>
    <?php
        $__scriptKey = '2312082915-0';
        ob_start();
    ?>
    <script>
        $wire.on('alert', (event) => {
            Toastify({
                text: event[0]['message'],
                duration: 3000,
                gravity: "bottom", // `top` or `bottom`
                position: "right", // `left`, `center` or `right`
                stopOnFocus: true, // Prevents dismissing of toast on hover
                style: {
                    background: "black",
                },
                onClick: function() {} // Callback after click
            }).showToast();
        });
    </script>
    <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
<?php /**PATH D:\PROJECT\NEWS\news\resources\views/livewire/news.blade.php ENDPATH**/ ?>