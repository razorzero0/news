<?php
    function cekActive($route)
    {
        if ($route == Request::segment(count(Request::segments()))) {
            return 'tabActive';
        }
    }
?>
<nav
    class=" dark:bg-gray-900 fixed w-full  top-0 start-0 dark:border-gray-800 backdrop-blur-md bg-slate-800/90 z-[999]  border-b-1 border-slate-700 shadow-md shadow-slate-900">
    <div class="">
        <script src="https://widgets.coingecko.com/gecko-coin-price-marquee-widget.js"></script>
        <gecko-coin-price-marquee-widget locale="en" dark-mode="true" coin-ids=""
            initial-currency="idr"></gecko-coin-price-marquee-widget>
    </div>
    <div class="flex flex-wrap items-center justify-between max-w-screen-xl p-1 px-8 mx-auto">
        <div class="flex items-center gap-5">

            <a href=<?php echo e(route('index')); ?> wire:navigate class="flex space-x-1 rtl:space-x-reverse">
                
                <span class="text-lg font-bold text-white whitespace-nowrap">Algoora<mark
                        class="text-white bg-blue-600 rounded pe-1 dark:bg-blue-500">News</mark> </span>
            </a>


            <div class="hidden lg:block">
                <ul class="flex flex-wrap -mb-px font-sans text-lg text-center ">
                    

                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="me-2 <?php echo e(cekActive($category->name)); ?> ">
                            <a wire:navigate href=<?php echo e(route('category-find', $category->name)); ?>

                                class="inline-flex items-center justify-center p-4 text-gray-200 border-b-2 border-transparent rounded-t-lg hover:text-indigo-500 group">
                                <?php echo e($category->name); ?>

                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->


                </ul>
            </div>

        </div>

        <div class="hidden gap-2 space-x-3 sm:flex md:order-2 md:space-x-0 rtl:space-x-reverse">


            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('navbar-search');

$__html = app('livewire')->mount($__name, $__params, 'lw-1598048776-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

            <!--[if BLOCK]><![endif]--><?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('dashboard')); ?>"
                    class="flex items-center justify-center h-10 px-6 text-sm font-medium text-center text-white bg-purple-700 border border-purple-900 rounded-lg hover:bg-purple-900 focus:ring-4 focus:outline-none focus:ring-purple-950"
                    wire:navigate>Panel</a>

            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <!--[if BLOCK]><![endif]--><?php if(auth()->guard()->guest()): ?>
                <a href=<?php echo e(route('login')); ?>

                    class="flex items-center justify-center h-10 px-6 text-sm font-medium text-center text-white border rounded-lg bg-slate-800 hover:bg-slate-600 focus:ring-4 focus:outline-none focus:ring-gray-600 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-800 border-slate-600"
                    wire:navigate>Masuk</a>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->





        </div>
        <div class="block sm:hidden">
            <button
                class="px-5 py-2 my-1 text-sm font-medium text-white bg-purple-700 border border-purple-900 rounded-lg sm:my-0 hover:bg-purple-900 "
                type="button" data-drawer-target="drawer-navigation" data-drawer-show="drawer-navigation"
                aria-controls="drawer-navigation">
                <svg class="w-4 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                    viewBox="0 0 17 14">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M1 1h15M1 7h15M1 13h15" />
                </svg>
            </button>
        </div>
        <?php echo $__env->make('livewire.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

</nav>
<?php /**PATH D:\PROJECT\NEWS\news\resources\views/livewire/layouts/home-navbar.blade.php ENDPATH**/ ?>