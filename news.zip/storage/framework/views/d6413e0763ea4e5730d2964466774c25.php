<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Dashboard AlgooraNews</title>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>


    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

</head>

<body class="bg-gray-900 ">
    <?php echo $__env->yieldContent('content'); ?>
</body>

</html>
<?php /**PATH D:\PROJECT\NEWS\news\resources\views/auth/layouts/app.blade.php ENDPATH**/ ?>