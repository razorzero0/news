<div class="relative max-w-screen-xl p-5 mx-auto mt-24 md:mt-20 sm:p-10 md:p-16">


    <div class="grid grid-cols-1 gap-10 sm:grid-cols-12">


        <div class="sm:col-span-6 lg:col-span-6">
            <div class="flex mb-5 text-sm border-b border-slate-600">
                <div class="flex items-center pb-2 pr-2 uppercase ">
                    <a href="#" class="inline-block font-bold text-md"> <span class="text-slate-100">FEATURED
                            POST</span>
                    </a>
                </div>
            </div>
            <div class="bg-gray-800 rounded-lg ">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('home.featured', ['lazy' => true]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3946754918-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        </div>


        <?php echo $__env->make('livewire.home_partials.popular', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>


    <?php echo $__env->make('livewire.home_partials.otherPost', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



</div>
<?php /**PATH D:\PROJECT\NEWS\news\resources\views/livewire/home.blade.php ENDPATH**/ ?>