<!-- resources/views/components/layouts/app.blade.php -->
<!DOCTYPE html>
<html lang="en">

<head>

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>AlgooraNews - Berita Seputar Cryptocurrency</title>

        <!-- General SEO Meta Tags -->
        <meta name="description"
            content="AlgooraNews adalah platform terpercaya yang menyajikan berita terbaru dan informasi mendalam seputar dunia cryptocurrency, blockchain, dan aset digital lainnya.">
        <meta name="keywords"
            content="AlgooraNews, berita cryptocurrency, blockchain, aset digital, informasi crypto, berita terbaru crypto, analisis pasar crypto">
        <meta name="author" content="AlgooraNews">

        <!-- Open Graph / Facebook -->
        <meta property="og:title" content="AlgooraNews - Berita Terbaru Cryptocurrency">
        <meta property="og:description"
            content="Ikuti berita terbaru, analisis pasar, dan perkembangan terkini dunia cryptocurrency hanya di AlgooraNews.">
        <meta property="og:image" content="<?php echo e(asset('assets/img/logo/logo-min.jpg')); ?>">
        <meta property="og:url" content="<?php echo e(env('APP_URL')); ?>">
        <meta property="og:type" content="website">

        <!-- Twitter Meta Tags -->
        <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:title" content="AlgooraNews - Berita Terbaru Cryptocurrency">
        <meta name="twitter:description"
            content="Dapatkan informasi terkini dan terpercaya tentang dunia cryptocurrency, blockchain, dan aset digital di AlgooraNews.">
        <meta name="twitter:image" content="<?php echo e(asset('assets/img/logo/logo-min.jpg')); ?>">

        <!-- WhatsApp Sharing Meta Tags -->
        <meta property="og:image" content="<?php echo e(asset('assets/img/logo/logo-min.jpg')); ?>">
        <meta property="og:description"
            content="Platform berita terpercaya untuk berita terbaru, analisis, dan wawasan seputar cryptocurrency di AlgooraNews.">

        <!-- Favicon -->
        <link rel="icon" href="<?php echo e(asset('assets/img/favicon/favicon-32x32.png')); ?>" type="image/x-icon">

    </head>

    <?php echo $__env->yieldPushContent('styles'); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>


</head>

<body x-init="initFlowbite();" class="bg-gray-900 ">
    
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('home-navbar');

$__html = app('livewire')->mount($__name, $__params, 'lw-2038886247-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

    <?php echo e($slot); ?> <!-- Ini akan menampilkan konten dari Livewire component -->


    <?php echo $__env->yieldPushContent('scripts'); ?>

    <?php echo $__env->make('livewire.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



</body>

</html>
<?php /**PATH D:\PROJECT\NEWS\news\resources\views/livewire/layouts/app.blade.php ENDPATH**/ ?>