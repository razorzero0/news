<img class="h-28" src="<?php echo e(asset('assets/img/logo/logo-color.png')); ?>" />
<?php /**PATH D:\PROJECT\NEWS\news\resources\views/components/application-logo.blade.php ENDPATH**/ ?>