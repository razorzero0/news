<img class="h-28" src="{{ asset('assets/img/logo/logo-color.png') }}" />
